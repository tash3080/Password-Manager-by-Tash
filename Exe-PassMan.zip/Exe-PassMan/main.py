from tkinter import *
from tkinter import ttk
import random
import string
import sqlite3

con = sqlite3.connect("passworddb2.db")
cur = con.cursor()

cur.execute('''
CREATE TABLE IF NOT EXISTS credentials(
    site TEXT,
    email TEXT,
    username TEXT,
    password TEXT
)''')


app = Tk()
app.title("Password Manager")
#app.geometry("500x400")
app.configure(background= "#7acdfa")

pw_len = StringVar()
#pw_len.set(8)
password = StringVar()

website = StringVar()
username = StringVar()
email = StringVar()


passwd = ''

def generate():
    global passwd
    all = string.ascii_uppercase + string.ascii_lowercase + string.digits + string.punctuation
    temp = random.sample(all,int(pw_len.get()))
    passwd = "".join(temp)
    password.set(passwd)

def save():
    global website 
    global username
    global email
    global password
    
    con = sqlite3.connect("passworddb2.db")
    cur = con.cursor()
    cur.execute('''
    INSERT INTO credentials (site, email, username, password) VALUES ( ?, ?, ?, ? )
    ''', 
    (website.get(), email.get(), username.get(), password.get()))
    pw_data.insert(parent='', text='', index='end', 
                    values=(website.get(), username.get(), email.get(), password.get()))
    con.commit()
    con.close()
    

def search():
    con = sqlite3.connect("passworddb2.db")
    cur = con.cursor()
    cur.execute('SELECT * FROM credentials WHERE site=?', (website.get(),))
    serach_result = cur.fetchall()
    for row in serach_result:
        pw_data.insert(parent="", text="", index='end', values=(row[0], row[1], row[2], row[3]))
    con.commit()
    con.close()

def show_all():
    con = sqlite3.connect("passworddb2.db")
    cur = con.cursor()
    cur.execute('''
    SELECT * FROM credentials''')
    all_data = cur.fetchall()
    print(all_data)
    for row in all_data :
        print(row)
        pw_data.insert(parent="", text="", index='end', values=(row[0], row[1], row[2], row[3]))
    con.commit()
    con.close()



def update():
    con = sqlite3.connect("passworddb2.db")
    cur = con.cursor()
    cur.execute('UPDATE credentials SET password=? WHERE site=? AND email=?', (password.get(), website.get(), email.get()))
    cur.execute('SELECT * FROM credentials WHERE site=? AND password=?', (website.get(), password.get()))
    updated_cred = cur.fetchall()
    for row in updated_cred:
        pw_data.insert(parent="", text="", index='end', values=(row[0], row[1], row[2], row[3]))
    con.commit()
    con.close()

def delete():
    con = sqlite3.connect("passworddb2.db")
    cur = con.cursor()
    cur.execute('DELETE FROM credentials WHERE site=? AND email=? AND password=?', (website.get(),email.get(), password.get()))
    con.commit()
    con.close()

frame1 = Frame(app)
frame1.grid()

frame2 = Frame(frame1, width= 15)
frame2.grid()

label1_pw = Label(frame1, text="Password", width= 15)
label2_uid = Label(frame1, text="User ID")
label3_em = Label(frame1, text="Email")
label4_site = Label(frame1, text="Site")

label5_pl = Label(frame2, text= "PW Length")

entry1_pw = Entry(frame1, width= 20, textvariable=password)
entry2_uid = Entry(frame1, textvariable=username)
entry3_em = Entry(frame1, textvariable= email)
entry4_site = Entry(frame1, textvariable=website)


entry5_pl = Entry(frame2, width=5, textvariable=pw_len)



#drop_down1_pl = ttk.Combobox(app, textvariable= pass_len).pack()

button1_gen = Button(frame1, text="Generate", width=10, command=generate)
button2_save = Button(frame1, text="Save", width=10, command=save)
button3_search = Button(frame1, text="Search", width=10, command=search)
button4_show = Button(frame1, text="Show all", width=10, command=show_all)
button5_update = Button(frame1, text="Update", width=10, command = update)
button6_del = Button(frame1, text="Delete", width=10, command=delete)

label5_pl.grid(row=0, column=0)
entry5_pl.grid(row=0, column=1)


label1_pw.grid(row=0, column=0)
entry1_pw.grid(row=0, column=1)
frame2.grid(row=0, column=2)

label2_uid.grid(row=1, column= 0)
entry2_uid.grid(row=1, column= 1)
button1_gen.grid(row=1, column= 2)

label3_em.grid(row=2, column= 0)
entry3_em.grid(row=2, column= 1)
button2_save.grid(row=2, column= 2)

label4_site.grid(row=3, column= 0)
entry4_site.grid(row=3, column= 1)
button3_search.grid(row=3, column= 2)

button4_show.grid(row=4, column= 0)
button5_update.grid(row=4, column= 1)
button6_del.grid(row=4, column= 2)


pw_data = ttk.Treeview(frame1)
pw_data["columns"] = ("site", "email", "username", "password")
pw_data.column("#0", width=0, stretch= NO)
pw_data.column("site", width=20)
pw_data.column("email", width=20)
pw_data.column("username", width=20)
pw_data.column("password", width=20)
pw_data.heading("site", text="Site")
pw_data.heading("email", text="Email")
pw_data.heading("username", text="Username")
pw_data.heading("password", text="Password")

pw_data.grid(row=5, column=0, columnspan= 3, sticky= "nsew")

app.mainloop()